#!/bin/bash
echo "--- تقرير MASA الرقمي v10.0 ---"

# 1. قائمة الملفات
echo "[*] جاري حصر الملفات..."
ls -R | grep -v ":$" | grep -v "node_modules" > file_list.txt
echo "[✓] تم حصر $(wc -l < file_list.txt) ملف أساسي."

# 2. فحص سلامة الكود (البحث عن ثغرات شائعة أو أخطاء بناء)
echo "[*] فحص سلامة الكود..."
ERRORS=$(grep -r "require" . | grep -v "node_modules" | grep "null" | wc -l)
if [ $ERRORS -eq 0 ]; then
    echo "[✓] الكود يبدو سليماً (لا توجد أخطاء require فارغة واضحة)."
else
    echo "[!] تحذير: تم العثور على $ERRORS أماكن قد تسبب مشاكل (require null)."
fi

# 3. الوزن الرقمي (الحجم)
echo "[*] حساب الوزن الرقمي (بدون المجلدات الثقيلة)..."
SIZE=$(du -sh . --exclude="node_modules" --exclude=".git" | cut -f1)
echo "[✓] الحجم الصافي للكود (بدون المكتبات): $SIZE"

# 4. عرض ملخص الملفات
echo -e "\n--- قائمة الملفات الأساسية ---"
cat file_list.txt
echo "------------------------------"
rm file_list.txt

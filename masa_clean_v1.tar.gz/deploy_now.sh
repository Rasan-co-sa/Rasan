#!/bin/bash
SVC_ID="srv-d4v3hvmr433s73du23t0"

# تهيئة المستودع في هذا المجلد
git init
git add .
git commit -m "Direct deploy from masa_work"
# تأكد من ربط المستودع برابط الـ GitHub الخاص بك
git remote add origin https://github.com/nasserjawabreh9-sys/Dwarf.git
git push -u origin main --force

echo -n "[!] ألصق Render API Key: "
read -s KEY
curl -s -X POST -H "Authorization: Bearer $KEY" "https://api.render.com/v1/services/$SVC_ID/deploys?clearCache=clear"
echo -e "\n[✓] تم دفع الكود وإرسال أمر البناء!"
